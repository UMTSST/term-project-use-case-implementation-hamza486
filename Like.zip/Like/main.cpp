#include <iostream>
#include <fstream>
#include<string>
#include <cstdlib>

using namespace std;

int main()
{



    ofstream Twitter("Twitter.txt", std::ios_base::app);
    //int clike=0;
    char User_ID[20], Like[2000], Time[20], Date[20];

    cout << "Enter Your Id and tweet with data and time" << endl;
    cout << "Enter User ID: ";
    gets(User_ID);
    Twitter <<"User ID :"<< User_ID << endl;
    cout << "You Like This Tweet :: YES/NO ";
    gets(Like);


    {Twitter <<"Likes :  "<<Like<< endl;}

    cout << "Enter Time Like hh:mm:sec :: ";
    gets(Time);
    Twitter <<"Time :" << Time << endl;
    cout << "Enter Date Like dd/mm/yy :: ";
    gets(Date);
    Twitter <<"Date :" << Date << endl;

    Twitter.close();


    return 0;
}
